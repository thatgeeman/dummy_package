def convert():
    print('convert data')